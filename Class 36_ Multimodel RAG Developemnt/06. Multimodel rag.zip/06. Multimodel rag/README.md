## How to run?

1. conda create -n llmapp python=3.11 -y 

2. conda activate llmapp 

3. pip install -r requirements.txt

4. pip install -r requirements-dev.txt




pip install openai==1.55.3 httpx==0.27.2

pip install transformers -U