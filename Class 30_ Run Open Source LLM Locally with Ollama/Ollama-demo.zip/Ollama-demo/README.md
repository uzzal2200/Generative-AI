conda create -n car python=3.11 -y

conda activate car

pip install -r requirements.txt