conda create -n agentrag python=3.12 -y

conda activate agentrag 

pip install -r requirements.txt