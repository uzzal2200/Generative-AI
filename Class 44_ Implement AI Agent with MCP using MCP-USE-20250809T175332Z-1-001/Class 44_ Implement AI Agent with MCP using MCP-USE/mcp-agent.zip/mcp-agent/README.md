1. Quality 
2. Affordibilty